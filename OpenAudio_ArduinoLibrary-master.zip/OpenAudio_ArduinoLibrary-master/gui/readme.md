This DesignTool_F32.zip holds the stand-alone Open Audio Design Tool for
floating point (F32) Teensy audio library.  Stand-alone means it has all
files necessary to run from a PC, without an Internet connection.
A Web browser is needed.

This ZIP file, on Github is up-to-date with the latest F32 Design Tool.

In order to make the Design Tool package available in a single click, a current
copy of the ZIP, that tracks GitHub, is mirrored at
http://www.janbob.com/electron/OpenAudio_Design_Tool/gui/DesignTool_F32.zip

To run the Design Tool from local storage,
create a new directory (folder) anywhere that it is convenient, and call it
something like DesignTool_F32. Copy the file DesignTool_F32.zip
to your new directory and extract all files. You can point your
browser at the file index.html and the Design Tool will be in full
operation.

The same Design Tool, browser ready, is also available on the Internet at:
http://www.janbob.com/electron/OpenAudio_Design_Tool/index.html
